from flask import Flask, render_template, request, jsonify
from textblob import TextBlob

app = Flask(__name__)

# Route for serving the frontend
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle sentiment prediction
@app.route('/predict', methods=['POST'])
def predict():
    user_input = request.json.get('text')  # Get user input from the request
    if user_input:
        # Use TextBlob to analyze sentiment
        blob = TextBlob(user_input)
        sentiment = blob.sentiment.polarity  # Polarity is between [-1, 1]

        # Classify sentiment based on polarity
        if sentiment > 0:
            result = 'Positive'
        elif sentiment < 0:
            result = 'Negative'
        else:
            result = 'Neutral'
        
        # Return the sentiment result as a JSON response
        return jsonify({'sentiment': result})
    
    return jsonify({'error': 'No text provided'})

if __name__ == '__main__':
    app.run(debug=True)
